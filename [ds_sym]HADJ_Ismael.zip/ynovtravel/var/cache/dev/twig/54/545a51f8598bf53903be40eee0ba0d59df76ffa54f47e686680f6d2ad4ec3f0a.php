<?php

/* TravellerTravelAdvisorBundle:Page:admin.html.twig */
class __TwigTemplate_344d20a4fb00bdf7c8ee276c6bf8f33c087280da9d8330471e6fe250147406f2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "TravellerTravelAdvisorBundle:Page:admin.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c6c01df749cc0a675c0aa02dcef6f53c7e8435e2bb7c0be9ea68f9ccd2779b5f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c6c01df749cc0a675c0aa02dcef6f53c7e8435e2bb7c0be9ea68f9ccd2779b5f->enter($__internal_c6c01df749cc0a675c0aa02dcef6f53c7e8435e2bb7c0be9ea68f9ccd2779b5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TravellerTravelAdvisorBundle:Page:admin.html.twig"));

        $__internal_f363d3c37553e39a426f52432a37245085eb921b4000fd3516623dcfeec44f38 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f363d3c37553e39a426f52432a37245085eb921b4000fd3516623dcfeec44f38->enter($__internal_f363d3c37553e39a426f52432a37245085eb921b4000fd3516623dcfeec44f38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TravellerTravelAdvisorBundle:Page:admin.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c6c01df749cc0a675c0aa02dcef6f53c7e8435e2bb7c0be9ea68f9ccd2779b5f->leave($__internal_c6c01df749cc0a675c0aa02dcef6f53c7e8435e2bb7c0be9ea68f9ccd2779b5f_prof);

        
        $__internal_f363d3c37553e39a426f52432a37245085eb921b4000fd3516623dcfeec44f38->leave($__internal_f363d3c37553e39a426f52432a37245085eb921b4000fd3516623dcfeec44f38_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_6ba663031018206ebe838d2acdcb39ce100b617665889da93889eeeb17134d94 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6ba663031018206ebe838d2acdcb39ce100b617665889da93889eeeb17134d94->enter($__internal_6ba663031018206ebe838d2acdcb39ce100b617665889da93889eeeb17134d94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_c7e196afd33de86ed790063b5827259691466fe9ce8cb2a10871b7923345cfc4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7e196afd33de86ed790063b5827259691466fe9ce8cb2a10871b7923345cfc4->enter($__internal_c7e196afd33de86ed790063b5827259691466fe9ce8cb2a10871b7923345cfc4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
<p> Espace admin</p>

";
        
        $__internal_c7e196afd33de86ed790063b5827259691466fe9ce8cb2a10871b7923345cfc4->leave($__internal_c7e196afd33de86ed790063b5827259691466fe9ce8cb2a10871b7923345cfc4_prof);

        
        $__internal_6ba663031018206ebe838d2acdcb39ce100b617665889da93889eeeb17134d94->leave($__internal_6ba663031018206ebe838d2acdcb39ce100b617665889da93889eeeb17134d94_prof);

    }

    public function getTemplateName()
    {
        return "TravellerTravelAdvisorBundle:Page:admin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\"%}

{%block body%}

<p> Espace admin</p>

{% endblock%}", "TravellerTravelAdvisorBundle:Page:admin.html.twig", "C:\\wamp64\\www\\ynovtravel\\src\\Traveller\\TravelAdvisorBundle/Resources/views/Page/admin.html.twig");
    }
}
