<?php

/* TravellerTravelAdvisorBundle:Page:voyage.html.twig */
class __TwigTemplate_3814e9cae3a6b8610e2d1411020d357b4fe60f238237e68bca2ae4947c82963d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "TravellerTravelAdvisorBundle:Page:voyage.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f52812a81ab04c1e1071e75eb6b5e050945c071742fbf6af22000bf4db14a439 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f52812a81ab04c1e1071e75eb6b5e050945c071742fbf6af22000bf4db14a439->enter($__internal_f52812a81ab04c1e1071e75eb6b5e050945c071742fbf6af22000bf4db14a439_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TravellerTravelAdvisorBundle:Page:voyage.html.twig"));

        $__internal_6ad2936e46682c29fd7ac12b45c9d810315af7175dee8791058532b14b2f1768 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6ad2936e46682c29fd7ac12b45c9d810315af7175dee8791058532b14b2f1768->enter($__internal_6ad2936e46682c29fd7ac12b45c9d810315af7175dee8791058532b14b2f1768_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TravellerTravelAdvisorBundle:Page:voyage.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f52812a81ab04c1e1071e75eb6b5e050945c071742fbf6af22000bf4db14a439->leave($__internal_f52812a81ab04c1e1071e75eb6b5e050945c071742fbf6af22000bf4db14a439_prof);

        
        $__internal_6ad2936e46682c29fd7ac12b45c9d810315af7175dee8791058532b14b2f1768->leave($__internal_6ad2936e46682c29fd7ac12b45c9d810315af7175dee8791058532b14b2f1768_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_a7954e9f711d271c0bcb87e8585a5b7ac88fe3b7da842bb9541c7060d1cdc63b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a7954e9f711d271c0bcb87e8585a5b7ac88fe3b7da842bb9541c7060d1cdc63b->enter($__internal_a7954e9f711d271c0bcb87e8585a5b7ac88fe3b7da842bb9541c7060d1cdc63b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_3dc441d3c895d80b99bdc909e4bfe023a010557c02af3493f20b1ab7e4bf58f5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3dc441d3c895d80b99bdc909e4bfe023a010557c02af3493f20b1ab7e4bf58f5->enter($__internal_3dc441d3c895d80b99bdc909e4bfe023a010557c02af3493f20b1ab7e4bf58f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
<p>Bienvenu sur TravelAdvisor ";
        // line 5
        echo twig_escape_filter($this->env, (isset($context["contenu"]) ? $context["contenu"] : $this->getContext($context, "contenu")), "html", null, true);
        echo "</p>

";
        
        $__internal_3dc441d3c895d80b99bdc909e4bfe023a010557c02af3493f20b1ab7e4bf58f5->leave($__internal_3dc441d3c895d80b99bdc909e4bfe023a010557c02af3493f20b1ab7e4bf58f5_prof);

        
        $__internal_a7954e9f711d271c0bcb87e8585a5b7ac88fe3b7da842bb9541c7060d1cdc63b->leave($__internal_a7954e9f711d271c0bcb87e8585a5b7ac88fe3b7da842bb9541c7060d1cdc63b_prof);

    }

    public function getTemplateName()
    {
        return "TravellerTravelAdvisorBundle:Page:voyage.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  52 => 5,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\"%}

{%block body%}

<p>Bienvenu sur TravelAdvisor {{contenu}}</p>

{% endblock%}", "TravellerTravelAdvisorBundle:Page:voyage.html.twig", "C:\\wamp64\\www\\ynovtravel\\src\\Traveller\\TravelAdvisorBundle/Resources/views/Page/voyage.html.twig");
    }
}
