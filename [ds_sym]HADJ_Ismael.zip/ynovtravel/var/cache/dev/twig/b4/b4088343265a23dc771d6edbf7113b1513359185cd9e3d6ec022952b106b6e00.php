<?php

/* base.html.twig */
class __TwigTemplate_8b9af363f79570f54baa8c6ff66ed3fd291fa90ae054c39ca27af4c2c64f332b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8f8ddb31512a033ff8c312be69a94538ea5d7c7cfc24978b00cf047a12032b3b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8f8ddb31512a033ff8c312be69a94538ea5d7c7cfc24978b00cf047a12032b3b->enter($__internal_8f8ddb31512a033ff8c312be69a94538ea5d7c7cfc24978b00cf047a12032b3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_5f0029abb422e76d6b58c8b0e01a58975cc576bd393af0a927cab0ab13eb1036 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5f0029abb422e76d6b58c8b0e01a58975cc576bd393af0a927cab0ab13eb1036->enter($__internal_5f0029abb422e76d6b58c8b0e01a58975cc576bd393af0a927cab0ab13eb1036_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>


    <footer>
    ";
        // line 16
        $this->displayBlock('footer', $context, $blocks);
        // line 17
        echo "    </footer>
</html>
";
        
        $__internal_8f8ddb31512a033ff8c312be69a94538ea5d7c7cfc24978b00cf047a12032b3b->leave($__internal_8f8ddb31512a033ff8c312be69a94538ea5d7c7cfc24978b00cf047a12032b3b_prof);

        
        $__internal_5f0029abb422e76d6b58c8b0e01a58975cc576bd393af0a927cab0ab13eb1036->leave($__internal_5f0029abb422e76d6b58c8b0e01a58975cc576bd393af0a927cab0ab13eb1036_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_fe704afda3422c6df23bfcb46077bac1950099aad23f764048dbc74619608407 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fe704afda3422c6df23bfcb46077bac1950099aad23f764048dbc74619608407->enter($__internal_fe704afda3422c6df23bfcb46077bac1950099aad23f764048dbc74619608407_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_8c27dee9156c57352fa347b47fbc66339b9124426205404d1b2709921b334032 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8c27dee9156c57352fa347b47fbc66339b9124426205404d1b2709921b334032->enter($__internal_8c27dee9156c57352fa347b47fbc66339b9124426205404d1b2709921b334032_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_8c27dee9156c57352fa347b47fbc66339b9124426205404d1b2709921b334032->leave($__internal_8c27dee9156c57352fa347b47fbc66339b9124426205404d1b2709921b334032_prof);

        
        $__internal_fe704afda3422c6df23bfcb46077bac1950099aad23f764048dbc74619608407->leave($__internal_fe704afda3422c6df23bfcb46077bac1950099aad23f764048dbc74619608407_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_0cf6c0a3a4c5b5c98e0ba39ddc91fcf6b426e7b744a121470139b638b4a38442 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0cf6c0a3a4c5b5c98e0ba39ddc91fcf6b426e7b744a121470139b638b4a38442->enter($__internal_0cf6c0a3a4c5b5c98e0ba39ddc91fcf6b426e7b744a121470139b638b4a38442_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_0daf3fd03721e63c270cd3542ff86e9b04f188a4c22698e2d7354d88ff7a4141 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0daf3fd03721e63c270cd3542ff86e9b04f188a4c22698e2d7354d88ff7a4141->enter($__internal_0daf3fd03721e63c270cd3542ff86e9b04f188a4c22698e2d7354d88ff7a4141_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_0daf3fd03721e63c270cd3542ff86e9b04f188a4c22698e2d7354d88ff7a4141->leave($__internal_0daf3fd03721e63c270cd3542ff86e9b04f188a4c22698e2d7354d88ff7a4141_prof);

        
        $__internal_0cf6c0a3a4c5b5c98e0ba39ddc91fcf6b426e7b744a121470139b638b4a38442->leave($__internal_0cf6c0a3a4c5b5c98e0ba39ddc91fcf6b426e7b744a121470139b638b4a38442_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_8e76ff4a63cfcf6d77edffba1c90b721214a4f4cea6e42cbb196e2294854f865 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8e76ff4a63cfcf6d77edffba1c90b721214a4f4cea6e42cbb196e2294854f865->enter($__internal_8e76ff4a63cfcf6d77edffba1c90b721214a4f4cea6e42cbb196e2294854f865_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_cfd40605bb571f78440483f99d09c2f9d2c19e76d4805756e5d976fa978850ea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cfd40605bb571f78440483f99d09c2f9d2c19e76d4805756e5d976fa978850ea->enter($__internal_cfd40605bb571f78440483f99d09c2f9d2c19e76d4805756e5d976fa978850ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_cfd40605bb571f78440483f99d09c2f9d2c19e76d4805756e5d976fa978850ea->leave($__internal_cfd40605bb571f78440483f99d09c2f9d2c19e76d4805756e5d976fa978850ea_prof);

        
        $__internal_8e76ff4a63cfcf6d77edffba1c90b721214a4f4cea6e42cbb196e2294854f865->leave($__internal_8e76ff4a63cfcf6d77edffba1c90b721214a4f4cea6e42cbb196e2294854f865_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_fe4fbe4e36c961648d333465280305bb8bbe8c1ddf9be3489d32ca6c00a652d4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fe4fbe4e36c961648d333465280305bb8bbe8c1ddf9be3489d32ca6c00a652d4->enter($__internal_fe4fbe4e36c961648d333465280305bb8bbe8c1ddf9be3489d32ca6c00a652d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_715fa1b13d2e8d37307bc040579891c8573447c5a67bb33685cc3a9254159756 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_715fa1b13d2e8d37307bc040579891c8573447c5a67bb33685cc3a9254159756->enter($__internal_715fa1b13d2e8d37307bc040579891c8573447c5a67bb33685cc3a9254159756_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_715fa1b13d2e8d37307bc040579891c8573447c5a67bb33685cc3a9254159756->leave($__internal_715fa1b13d2e8d37307bc040579891c8573447c5a67bb33685cc3a9254159756_prof);

        
        $__internal_fe4fbe4e36c961648d333465280305bb8bbe8c1ddf9be3489d32ca6c00a652d4->leave($__internal_fe4fbe4e36c961648d333465280305bb8bbe8c1ddf9be3489d32ca6c00a652d4_prof);

    }

    // line 16
    public function block_footer($context, array $blocks = array())
    {
        $__internal_1d045af0d3349e3c514ec14d05d82e20ff1aaaa304ab6b671db964cdc65ac197 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1d045af0d3349e3c514ec14d05d82e20ff1aaaa304ab6b671db964cdc65ac197->enter($__internal_1d045af0d3349e3c514ec14d05d82e20ff1aaaa304ab6b671db964cdc65ac197_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_d049b584afdb0caf3172c5f7ad918b5970e6962ba337dbbcc679a452a17df4be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d049b584afdb0caf3172c5f7ad918b5970e6962ba337dbbcc679a452a17df4be->enter($__internal_d049b584afdb0caf3172c5f7ad918b5970e6962ba337dbbcc679a452a17df4be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        
        $__internal_d049b584afdb0caf3172c5f7ad918b5970e6962ba337dbbcc679a452a17df4be->leave($__internal_d049b584afdb0caf3172c5f7ad918b5970e6962ba337dbbcc679a452a17df4be_prof);

        
        $__internal_1d045af0d3349e3c514ec14d05d82e20ff1aaaa304ab6b671db964cdc65ac197->leave($__internal_1d045af0d3349e3c514ec14d05d82e20ff1aaaa304ab6b671db964cdc65ac197_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  143 => 16,  126 => 11,  109 => 10,  92 => 6,  74 => 5,  62 => 17,  60 => 16,  54 => 12,  51 => 11,  49 => 10,  42 => 7,  40 => 6,  36 => 5,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>


    <footer>
    {%block footer%}{% endblock %}
    </footer>
</html>
", "base.html.twig", "C:\\wamp64\\www\\ynovtravel\\app\\Resources\\views\\base.html.twig");
    }
}
