<?php

/* TravellerTravelAdvisorBundle:Page:voyageprenom.html.twig */
class __TwigTemplate_2fb12ab1de8d9efc1aaa3cbede7dd2a4f1c54d7a470592e263cddbe3b6722d0c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a3ec6905d88602464f63a2737d8557f2df7341aa035c4754c64d220c3ad66cee = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a3ec6905d88602464f63a2737d8557f2df7341aa035c4754c64d220c3ad66cee->enter($__internal_a3ec6905d88602464f63a2737d8557f2df7341aa035c4754c64d220c3ad66cee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TravellerTravelAdvisorBundle:Page:voyageprenom.html.twig"));

        $__internal_a8acd9367b1ae89e68b655d8a86f1dbfe884a766dca3dfaf3f2c4341586fe448 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a8acd9367b1ae89e68b655d8a86f1dbfe884a766dca3dfaf3f2c4341586fe448->enter($__internal_a8acd9367b1ae89e68b655d8a86f1dbfe884a766dca3dfaf3f2c4341586fe448_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TravellerTravelAdvisorBundle:Page:voyageprenom.html.twig"));

        // line 1
        echo "<body>
<p>Bienvenu sur TravelAdvisor ";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["contenu"]) ? $context["contenu"] : $this->getContext($context, "contenu")), "html", null, true);
        echo "</p>
</body>";
        
        $__internal_a3ec6905d88602464f63a2737d8557f2df7341aa035c4754c64d220c3ad66cee->leave($__internal_a3ec6905d88602464f63a2737d8557f2df7341aa035c4754c64d220c3ad66cee_prof);

        
        $__internal_a8acd9367b1ae89e68b655d8a86f1dbfe884a766dca3dfaf3f2c4341586fe448->leave($__internal_a8acd9367b1ae89e68b655d8a86f1dbfe884a766dca3dfaf3f2c4341586fe448_prof);

    }

    public function getTemplateName()
    {
        return "TravellerTravelAdvisorBundle:Page:voyageprenom.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<body>
<p>Bienvenu sur TravelAdvisor {{contenu}}</p>
</body>", "TravellerTravelAdvisorBundle:Page:voyageprenom.html.twig", "C:\\wamp64\\www\\ynovtravel\\src\\Traveller\\TravelAdvisorBundle/Resources/views/Page/voyageprenom.html.twig");
    }
}
