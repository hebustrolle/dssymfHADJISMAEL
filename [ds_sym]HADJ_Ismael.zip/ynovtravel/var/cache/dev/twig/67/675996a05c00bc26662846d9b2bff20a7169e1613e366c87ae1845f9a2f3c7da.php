<?php

/* TravellerTravelAdvisorBundle:Default:index.html.twig */
class __TwigTemplate_ae4ac95600114d65a47e40636881009ddd88ce6e94562eaf3f217cfb8a6e6e5a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2e6fbb9a6d31b60d4ac44d199822a0e8704f3c9f80d15765fd5d4a49feaa8914 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2e6fbb9a6d31b60d4ac44d199822a0e8704f3c9f80d15765fd5d4a49feaa8914->enter($__internal_2e6fbb9a6d31b60d4ac44d199822a0e8704f3c9f80d15765fd5d4a49feaa8914_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TravellerTravelAdvisorBundle:Default:index.html.twig"));

        $__internal_6d181b1bfd62a8c82a27a1fc74d9186ce61d41cdcc4dde773fc7507b945b6d4b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d181b1bfd62a8c82a27a1fc74d9186ce61d41cdcc4dde773fc7507b945b6d4b->enter($__internal_6d181b1bfd62a8c82a27a1fc74d9186ce61d41cdcc4dde773fc7507b945b6d4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TravellerTravelAdvisorBundle:Default:index.html.twig"));

        // line 1
        echo "Hello World!
";
        
        $__internal_2e6fbb9a6d31b60d4ac44d199822a0e8704f3c9f80d15765fd5d4a49feaa8914->leave($__internal_2e6fbb9a6d31b60d4ac44d199822a0e8704f3c9f80d15765fd5d4a49feaa8914_prof);

        
        $__internal_6d181b1bfd62a8c82a27a1fc74d9186ce61d41cdcc4dde773fc7507b945b6d4b->leave($__internal_6d181b1bfd62a8c82a27a1fc74d9186ce61d41cdcc4dde773fc7507b945b6d4b_prof);

    }

    public function getTemplateName()
    {
        return "TravellerTravelAdvisorBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Hello World!
", "TravellerTravelAdvisorBundle:Default:index.html.twig", "C:\\wamp64\\www\\ynovtravel\\src\\Traveller\\TravelAdvisorBundle/Resources/views/Default/index.html.twig");
    }
}
