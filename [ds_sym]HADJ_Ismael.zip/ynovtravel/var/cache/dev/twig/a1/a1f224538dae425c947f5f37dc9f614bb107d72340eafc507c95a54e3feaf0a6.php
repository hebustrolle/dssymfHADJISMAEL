<?php

/* TravellerTravelAdvisorBundle:Page:connection.html.twig */
class __TwigTemplate_178b4eb51f304e52db67991ea0b10f1b9f104132be6adc7cd6b917c6cb326d0e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "TravellerTravelAdvisorBundle:Page:connection.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_49c41b196df224a417274e5aeff6642cb611db3f67ebd88934377d841cc3ad5b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_49c41b196df224a417274e5aeff6642cb611db3f67ebd88934377d841cc3ad5b->enter($__internal_49c41b196df224a417274e5aeff6642cb611db3f67ebd88934377d841cc3ad5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TravellerTravelAdvisorBundle:Page:connection.html.twig"));

        $__internal_8768a5f8fcca4fda57fd004acb86906531436a8f5e31659c2ceaf19f441cd15a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8768a5f8fcca4fda57fd004acb86906531436a8f5e31659c2ceaf19f441cd15a->enter($__internal_8768a5f8fcca4fda57fd004acb86906531436a8f5e31659c2ceaf19f441cd15a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TravellerTravelAdvisorBundle:Page:connection.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_49c41b196df224a417274e5aeff6642cb611db3f67ebd88934377d841cc3ad5b->leave($__internal_49c41b196df224a417274e5aeff6642cb611db3f67ebd88934377d841cc3ad5b_prof);

        
        $__internal_8768a5f8fcca4fda57fd004acb86906531436a8f5e31659c2ceaf19f441cd15a->leave($__internal_8768a5f8fcca4fda57fd004acb86906531436a8f5e31659c2ceaf19f441cd15a_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_f213e1feb04d22ff032f390c7b10c59bc9382158548a4295dc05f35ae58c74e7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f213e1feb04d22ff032f390c7b10c59bc9382158548a4295dc05f35ae58c74e7->enter($__internal_f213e1feb04d22ff032f390c7b10c59bc9382158548a4295dc05f35ae58c74e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_c0b2d55c4021f783f512a3a4c572fde47eb8844815c5f4ca8df47bfe136de215 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c0b2d55c4021f783f512a3a4c572fde47eb8844815c5f4ca8df47bfe136de215->enter($__internal_c0b2d55c4021f783f512a3a4c572fde47eb8844815c5f4ca8df47bfe136de215_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<form>
Pseudo<input type=\"text\" name=\"pseudo\" placeholder=\"pseudo\"><br>
Mot de passe<input type=\"password\" name=\"mdp\" placeholder=\"mot de passe\"><br>
<input type=\"submit\" name=\"\">
</form>

";
        
        $__internal_c0b2d55c4021f783f512a3a4c572fde47eb8844815c5f4ca8df47bfe136de215->leave($__internal_c0b2d55c4021f783f512a3a4c572fde47eb8844815c5f4ca8df47bfe136de215_prof);

        
        $__internal_f213e1feb04d22ff032f390c7b10c59bc9382158548a4295dc05f35ae58c74e7->leave($__internal_f213e1feb04d22ff032f390c7b10c59bc9382158548a4295dc05f35ae58c74e7_prof);

    }

    public function getTemplateName()
    {
        return "TravellerTravelAdvisorBundle:Page:connection.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\"%}

{%block body%}
<form>
Pseudo<input type=\"text\" name=\"pseudo\" placeholder=\"pseudo\"><br>
Mot de passe<input type=\"password\" name=\"mdp\" placeholder=\"mot de passe\"><br>
<input type=\"submit\" name=\"\">
</form>

{% endblock%}", "TravellerTravelAdvisorBundle:Page:connection.html.twig", "C:\\wamp64\\www\\ynovtravel\\src\\Traveller\\TravelAdvisorBundle/Resources/views/Page/connection.html.twig");
    }
}
