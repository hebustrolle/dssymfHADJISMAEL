<?php

/* @TravellerTravelAdvisor/Default/index.html.twig */
class __TwigTemplate_2329eef5258847e2597b58ef41e966a47c81e514838d71cf6c0c7bb70246acc0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "Hello World!
";
    }

    public function getTemplateName()
    {
        return "@TravellerTravelAdvisor/Default/index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@TravellerTravelAdvisor/Default/index.html.twig", "C:\\wamp64\\www\\ynovtravel\\src\\Traveller\\TravelAdvisorBundle\\Resources\\views\\Default\\index.html.twig");
    }
}
