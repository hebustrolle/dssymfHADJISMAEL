<?php

namespace Traveller\TravelAdvisorBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TravellerTravelAdvisorBundle extends Bundle
{
}
