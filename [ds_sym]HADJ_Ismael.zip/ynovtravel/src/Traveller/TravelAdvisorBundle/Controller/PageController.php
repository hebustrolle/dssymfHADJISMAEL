<?php

namespace Traveller\TravelAdvisorBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class PageController extends Controller
{
    public function voyageAction()
    {
    	$contenu = "";
        return $this->render('TravellerTravelAdvisorBundle:Page:voyage.html.twig', ["contenu"=>$contenu]);
    }

    public function viewAction($prenom)
    {
    	$contenu = $prenom;
        return $this->render('TravellerTravelAdvisorBundle:Page:voyage.html.twig', ["contenu"=>$contenu]);
    }


      public function adminAction()
    {
        return $this->render('TravellerTravelAdvisorBundle:Page:admin.html.twig');
    }


          public function redirectAction()
    {

    	$contenu = "";
        return $this->render('TravellerTravelAdvisorBundle:Page:voyage.html.twig', ["contenu"=>$contenu]);
    }


           public function connectionAction()
    {
        return $this->render('TravellerTravelAdvisorBundle:Page:connection.html.twig');
    }
}
